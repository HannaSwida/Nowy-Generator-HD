CREATE DATABASE Policja 
GO

USE Policja
GO

CREATE TABLE Osoby
(
	Id INTEGER IDENTITY(1,1) PRIMARY KEY,
	Imie VARCHAR(191) NOT NULL,
	Nazwisko VARCHAR(191) NOT NULL,
	Pesel VARCHAR(191) NOT NULL,
	Numer_telefonu INTEGER NOT NULL,
	E_mail VARCHAR(191)
)
GO

CREATE TABLE Adresy
(
	Id INTEGER IDENTITY(1,1) PRIMARY KEY,
	Kraj VARCHAR(191) NOT NULL,
	Miasto VARCHAR(191) NOT NULL,
	Ulica VARCHAR(191) NOT NULL,
	Numer INTEGER NOT NULL
)
GO

CREATE TABLE Komisariat
(
	Id INTEGER IDENTITY(1,1) PRIMARY KEY,
	Nazwa VARCHAR(191) NOT NULL,
	
	Adres INTEGER NOT NULL,
	
	FOREIGN KEY(Adres) REFERENCES Adresy(Id)
)
GO

CREATE TABLE Funkcjonariusz
(
	Id INTEGER IDENTITY(1,1) PRIMARY KEY,
	Stopien VARCHAR(191) NOT NULL,
	
	Dane_osoby INTEGER NOT NULL,
	Miejsce_przydzialu INTEGER NOT NULL,
	
	FOREIGN KEY(Dane_osoby) REFERENCES Osoby(Id),
	FOREIGN KEY(Miejsce_przydzialu) REFERENCES Komisariat(Id),
)
GO

CREATE TABLE Wystawianie_mandatow
(
	Id INTEGER IDENTITY(1,1) PRIMARY KEY,
	Kwota INTEGER NOT NULL,
	Powod VARCHAR(191) NOT NULL,
	Czas_wystawienia DATETIME NOT NULL,
	
	Osoba_legitymowana INTEGER NOT NULL,
	Miejsce_zdarzenia INTEGER NOT NULL,
	Funkcjonariusz INTEGER NOT NULL,
	
	FOREIGN KEY(Osoba_legitymowana) REFERENCES Osoby(Id),
	FOREIGN KEY(Miejsce_zdarzenia) REFERENCES Adresy(Id),
	FOREIGN KEY(Funkcjonariusz) REFERENCES Funkcjonariusz(Id),
)
GO

CREATE TABLE Przebywanie_w_areszcie
(
	Id INTEGER IDENTITY(1,1) PRIMARY KEY,
	Czas INTEGER NOT NULL,
	Czas_interwencji DATETIME NOT NULL,
	Powod VARCHAR(191) NOT NULL,
	
	Dane_osadzonego INTEGER NOT NULL,
	Funkcjonariusz INTEGER NOT NULL,
	Komisariat INTEGER NOT NULL,
	
	FOREIGN KEY(Dane_osadzonego) REFERENCES Osoby(Id),
	FOREIGN KEY(Funkcjonariusz) REFERENCES Funkcjonariusz(Id),
	FOREIGN KEY(Komisariat) REFERENCES Komisariat(Id),
)
GO